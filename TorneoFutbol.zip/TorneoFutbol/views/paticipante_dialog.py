from PySide6.QtWidgets import QDialog
from views.paticipante_dialog import Ui_Dialog # Nombre exacto según tu captura

class ParticipanteDialog(QDialog):
    def __init__(self, modelo_equipos, es_jugador=True, parent=None):
        super().__init__(parent)
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        
        self.es_jugador = es_jugador
        # Requisito 1.2: Diferenciar visualmente si es jugador o árbitro
        self.setWindowTitle("Nuevo Jugador" if es_jugador else "Nuevo Árbitro")

        # Rellenar el combo de equipos (Requisito 1.1 y 1.2)
        self.ui.combo_equipo.addItem("Sin equipo", None)
        for i in range(modelo_equipos.rowCount()):
            id_eq = modelo_equipos.index(i, 0).data()
            nombre_eq = modelo_equipos.index(i, 1).data()
            self.ui.combo_equipo.addItem(nombre_eq, id_eq)

        # Si es ÁRBITRO, deshabilitamos opciones de equipo (Requisito 1.2.3)
        if not self.es_jugador:
            self.ui.combo_equipo.setEnabled(False)
            self.ui.textEdit.setPlaceholderText("N/A para árbitros")
            self.ui.textEdit.setEnabled(False)

    def get_datos(self):
        """Retorna un diccionario con los datos para el controlador principal"""
        return {
            "nombre": self.ui.txt_nombre.text(),
            "rol": "Jugador" if self.es_jugador else "Árbitro",
            "id_equipo": self.ui.combo_equipo.currentData() if self.es_jugador else None,
            "posicion": self.ui.textEdit.toPlainText() if self.es_jugador else "Árbitro"
        }