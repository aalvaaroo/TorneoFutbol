# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainwindow.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QHBoxLayout, QHeaderView,
    QLabel, QMainWindow, QMenuBar, QPushButton,
    QSizePolicy, QStatusBar, QTabWidget, QTableView,
    QTreeView, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
    QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(927, 600)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout_4 = QVBoxLayout(self.centralwidget)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        self.equipos = QWidget()
        self.equipos.setObjectName(u"equipos")
        self.verticalLayout_6 = QVBoxLayout(self.equipos)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.tabla_equipos = QTableView(self.equipos)
        self.tabla_equipos.setObjectName(u"tabla_equipos")

        self.verticalLayout.addWidget(self.tabla_equipos)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.pushButton_2 = QPushButton(self.equipos)
        self.pushButton_2.setObjectName(u"pushButton_2")

        self.horizontalLayout.addWidget(self.pushButton_2)

        self.btn_edit_equipo = QPushButton(self.equipos)
        self.btn_edit_equipo.setObjectName(u"btn_edit_equipo")

        self.horizontalLayout.addWidget(self.btn_edit_equipo)

        self.btn_del_equipo = QPushButton(self.equipos)
        self.btn_del_equipo.setObjectName(u"btn_del_equipo")

        self.horizontalLayout.addWidget(self.btn_del_equipo)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.logo = QLabel(self.equipos)
        self.logo.setObjectName(u"logo")

        self.verticalLayout.addWidget(self.logo)


        self.verticalLayout_6.addLayout(self.verticalLayout)

        self.tabWidget.addTab(self.equipos, "")
        self.jugadores = QWidget()
        self.jugadores.setObjectName(u"jugadores")
        self.verticalLayout_5 = QVBoxLayout(self.jugadores)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.table_participantes = QTableView(self.jugadores)
        self.table_participantes.setObjectName(u"table_participantes")

        self.verticalLayout_5.addWidget(self.table_participantes)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.combo_filtro_equipo = QComboBox(self.jugadores)
        self.combo_filtro_equipo.addItem("")
        self.combo_filtro_equipo.addItem("")
        self.combo_filtro_equipo.setObjectName(u"combo_filtro_equipo")

        self.verticalLayout_2.addWidget(self.combo_filtro_equipo)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.btn_add_jugador = QPushButton(self.jugadores)
        self.btn_add_jugador.setObjectName(u"btn_add_jugador")

        self.horizontalLayout_4.addWidget(self.btn_add_jugador)

        self.btn_delete = QPushButton(self.jugadores)
        self.btn_delete.setObjectName(u"btn_delete")

        self.horizontalLayout_4.addWidget(self.btn_delete)


        self.verticalLayout_2.addLayout(self.horizontalLayout_4)


        self.verticalLayout_5.addLayout(self.verticalLayout_2)

        self.tabWidget.addTab(self.jugadores, "")
        self.calendario = QWidget()
        self.calendario.setObjectName(u"calendario")
        self.verticalLayout_7 = QVBoxLayout(self.calendario)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.tree_calendario = QTreeWidget(self.calendario)
        __qtreewidgetitem = QTreeWidgetItem()
        __qtreewidgetitem.setText(0, u"");
        self.tree_calendario.setHeaderItem(__qtreewidgetitem)
        self.tree_calendario.setObjectName(u"tree_calendario")

        self.verticalLayout_3.addWidget(self.tree_calendario)

        # self.treeView = QTreeView(self.calendario)
        # self.treeView.setObjectName(u"treeView")

        # self.verticalLayout_3.addWidget(self.treeView)

        self.pushButton_5 = QPushButton(self.calendario)
        self.pushButton_5.setObjectName(u"pushButton_5")

        self.verticalLayout_3.addWidget(self.pushButton_5)

        self.btn_clasificacion = QPushButton(self.calendario)
        self.btn_clasificacion.setObjectName(u"btn_clasificacion")

        self.verticalLayout_3.addWidget(self.btn_clasificacion)

        self.btn_nueva_temporada = QPushButton(self.calendario)
        self.btn_nueva_temporada.setObjectName(u"btn_nueva_temporada")

        self.verticalLayout_3.addWidget(self.btn_nueva_temporada)


        self.verticalLayout_7.addLayout(self.verticalLayout_3)

        self.tabWidget.addTab(self.calendario, "")
        self.creditos = QWidget()
        self.creditos.setObjectName(u"creditos")
        self.tabWidget.addTab(self.creditos, "")
        self.ayuda = QWidget()
        self.ayuda.setObjectName(u"ayuda")
        self.tabWidget.addTab(self.ayuda, "")

        self.verticalLayout_4.addWidget(self.tabWidget)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 927, 33))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"A\u00f1adir", None))
        self.btn_edit_equipo.setText(QCoreApplication.translate("MainWindow", u"Modificar", None))
        self.btn_del_equipo.setText(QCoreApplication.translate("MainWindow", u"Eliminar", None))
        self.logo.setText("")
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.equipos), QCoreApplication.translate("MainWindow", u"Equipos", None))
        self.combo_filtro_equipo.setItemText(0, QCoreApplication.translate("MainWindow", u"Jugadores", None))
        self.combo_filtro_equipo.setItemText(1, QCoreApplication.translate("MainWindow", u"\u00c1rbitros", None))

        self.btn_add_jugador.setText(QCoreApplication.translate("MainWindow", u"A\u00f1adir participante", None))
        self.btn_delete.setText(QCoreApplication.translate("MainWindow", u"Eliminar", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.jugadores), QCoreApplication.translate("MainWindow", u"Participantes", None))
        self.pushButton_5.setText(QCoreApplication.translate("MainWindow", u"Generar Siguiente Ronda", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.calendario), QCoreApplication.translate("MainWindow", u"Calendario", None))
        self.btn_clasificacion.setText(QCoreApplication.translate("MainWindow", u"Clasificaci\u00f3n", None))
        self.btn_nueva_temporada.setText(QCoreApplication.translate("MainWindow", u"Nueva Temporada", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.creditos), QCoreApplication.translate("MainWindow", u"Cr\u00e9ditos", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.ayuda), QCoreApplication.translate("MainWindow", u"Ayuda", None))
    # retranslateUi

