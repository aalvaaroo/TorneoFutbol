from PySide6.QtWidgets import (QDialog, QVBoxLayout, QFormLayout, QLineEdit, 
                             QComboBox, QCheckBox, QDialogButtonBox, QLabel, QDateEdit, QMessageBox)

class ParticipanteDialog(QDialog):
    def __init__(self, modelo_equipos, es_jugador=True, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Añadir Participante")
        self.setMinimumWidth(350)
        
        # Diseño principal
        layout = QVBoxLayout(self)
        form_layout = QFormLayout()

        # --- CAMPOS DEL FORMULARIO ---
        self.txt_nombre = QLineEdit()
        self.txt_nombre.setPlaceholderText("Nombre completo")

        self.date_nacimiento = QDateEdit()
        self.date_nacimiento.setCalendarPopup(True)
        self.date_nacimiento.setDate(self.date_nacimiento.date().currentDate().addYears(-18))  # Default 18 años atrás

        self.txt_posicion = QLineEdit()
        self.txt_posicion.setPlaceholderText("Ej: Delantero, Portero, Árbitro Principal...")

        # ComboBox para elegir equipo (usa la tabla 'equipos' de tu DB)
        self.combo_equipo = QComboBox()
        self.combo_equipos = modelo_equipos
        self.combo_equipo.setModel(modelo_equipos)
        self.combo_equipo.setModelColumn(1) # Muestra la columna 'nombre'

        # Roles (Basados en tus columnas es_jugador y es_arbitro)
        self.chk_jugador = QCheckBox("Es Jugador")
        self.chk_jugador.setChecked(es_jugador)
        
        self.chk_arbitro = QCheckBox("Es Árbitro")
        self.chk_arbitro.setChecked(not es_jugador)

        # Añadimos al formulario
        form_layout.addRow("Nombre:", self.txt_nombre)
        form_layout.addRow("Fecha Nacimiento:", self.date_nacimiento)
        form_layout.addRow("Posición/Rol:", self.txt_posicion)
        form_layout.addRow("Equipo:", self.combo_equipo)
        form_layout.addRow(self.chk_jugador)
        form_layout.addRow(self.chk_arbitro)

        layout.addLayout(form_layout)

        # --- BOTONES ---
        self.botones = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.botones.accepted.connect(self.accept)
        self.botones.rejected.connect(self.reject)
        layout.addWidget(self.botones)

    def accept(self):
        if not self.txt_nombre.text().strip():
            QMessageBox.warning(self, "Error", "El nombre es obligatorio.")
            return
        if not self.chk_jugador.isChecked() and not self.chk_arbitro.isChecked():
            QMessageBox.warning(self, "Error", "Debe seleccionar al menos un rol (Jugador o Árbitro).")
            return
        super().accept()

    def get_datos(self):
        """Devuelve los datos listos para insertar en la tabla 'participantes'"""
        # Obtenemos el ID real del equipo (columna 0)
        fila_seleccionada = self.combo_equipo.currentIndex()
        id_equipo = self.combo_equipo.model().index(fila_seleccionada, 0).data()
        curso = self.combo_equipo.model().index(fila_seleccionada, 2).data()  # columna 2 es curso

        return {
            "nombre": self.txt_nombre.text(),
            "fecha_nacimiento": self.date_nacimiento.date().toString("yyyy-MM-dd"),
            "posicion": self.txt_posicion.text(),
            "id_equipo": id_equipo,
            "es_jugador": self.chk_jugador.isChecked(),
            "es_arbitro": self.chk_arbitro.isChecked(),
            "curso": curso
        }