from PySide6.QtSql import QSqlTableModel, QSqlQuery, QSqlQueryModel, QSqlRelation, QSqlRelationalTableModel
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QMessageBox, QAbstractItemView, QTreeWidgetItem, QDialog, QVBoxLayout, QComboBox, QPushButton, QLabel, QLineEdit, QStyle, QTableView, QHeaderView, QHBoxLayout, QSpinBox
import os
import random

from controllers.equipo_dialog_controller import EquipoDialog
from controllers.image_delegate import ImageDelegate

class TorneoController:
    def __init__(self, vista):
        self.vista = vista
        self.inicializar_tablas()
        # self.agregar_opciones_profesionales()  # Comentado temporalmente para evitar error
        self.actualizar_calendario()
        self.conectar_botones()
        self.setup_creditos()
        self.setup_ayuda()
        self.setup_iconos()
        self.vista.ui.tabla_equipos.clicked.connect(self.al_seleccionar_equipo)
        self.vista.ui.tree_calendario.itemDoubleClicked.connect(self.editar_partido)
        # Limpiar participantes con nombres por defecto
        QSqlQuery().exec("DELETE FROM participantes WHERE nombre LIKE 'Nuevo%' OR nombre LIKE 'nuevo%' OR nombre = ''")
        # Aplicar filtro inicial
        self.filtrar_participantes()

    def inicializar_tablas(self):
        self.modelo_equipos = QSqlTableModel()
        self.modelo_equipos.setTable("equipos")
        self.modelo_equipos.setEditStrategy(QSqlTableModel.OnManualSubmit)
        self.modelo_equipos.select()
        self.modelo_equipos.setHeaderData(0, Qt.Horizontal, "ID")
        self.modelo_equipos.setHeaderData(1, Qt.Horizontal, "Nombre")
        self.modelo_equipos.setHeaderData(2, Qt.Horizontal, "Curso")
        self.modelo_equipos.setHeaderData(3, Qt.Horizontal, "Color")
        self.modelo_equipos.setHeaderData(4, Qt.Horizontal, "Escudo")
        self.vista.ui.tabla_equipos.setModel(self.modelo_equipos)
        
        self.delegate = ImageDelegate()
        self.vista.ui.tabla_equipos.setItemDelegateForColumn(4, self.delegate)
        self.vista.ui.tabla_equipos.verticalHeader().setDefaultSectionSize(50)
        self.vista.ui.tabla_equipos.setColumnWidth(4, 60)
        self.vista.ui.tabla_equipos.horizontalHeader().setSectionResizeMode(4, QHeaderView.Fixed)
        self.vista.ui.tabla_equipos.horizontalHeader().setStretchLastSection(True)
        self.vista.ui.tabla_equipos.resizeColumnsToContents()

        self.modelo_participantes = QSqlTableModel()
        self.modelo_participantes.setTable("participantes")
        self.modelo_participantes.select()
        self.modelo_participantes.setHeaderData(0, Qt.Horizontal, "ID")
        self.modelo_participantes.setHeaderData(1, Qt.Horizontal, "Nombre")
        self.modelo_participantes.setHeaderData(2, Qt.Horizontal, "Fecha Nacimiento")
        self.modelo_participantes.setHeaderData(3, Qt.Horizontal, "Curso")
        self.modelo_participantes.setHeaderData(4, Qt.Horizontal, "Es Jugador")
        self.modelo_participantes.setHeaderData(5, Qt.Horizontal, "Es Árbitro")
        self.modelo_participantes.setHeaderData(6, Qt.Horizontal, "Posición")
        self.modelo_participantes.setHeaderData(7, Qt.Horizontal, "Goles")
        self.modelo_participantes.setHeaderData(8, Qt.Horizontal, "Tarjetas Amarillas")
        self.modelo_participantes.setHeaderData(9, Qt.Horizontal, "Tarjetas Rojas")
        self.modelo_participantes.setHeaderData(10, Qt.Horizontal, "T. Rojas")
        self.vista.ui.table_participantes.setModel(self.modelo_participantes)

        self.vista.ui.tabla_equipos.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.vista.ui.table_participantes.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.vista.ui.table_participantes.resizeColumnsToContents()
        self.vista.ui.table_participantes.setColumnHidden(3, True)  # Ocultar columna curso

        self.vista.ui.tree_calendario.setColumnCount(4)
        self.vista.ui.tree_calendario.setHeaderLabels(["Fecha/Hora", "Partido", "Resultado", "Árbitro"])
        # Búsqueda para equipos
        self.vista.ui.verticalLayout.insertWidget(0, QLabel("Buscar Equipo:"))
        self.search_equipos = QLineEdit()
        self.search_equipos.setPlaceholderText("Escribe para filtrar...")
        self.vista.ui.verticalLayout.insertWidget(1, self.search_equipos)
        self.search_equipos.textChanged.connect(self.filtrar_equipos)
        
        # Filtro adicional para participantes: por equipo
        self.vista.ui.verticalLayout_2.insertWidget(0, QLabel("Filtrar por Equipo:"))
        self.combo_equipo_filtro = QComboBox()
        self.combo_equipo_filtro.addItem("Todos", "")
        query = QSqlQuery("SELECT id, nombre FROM equipos ORDER BY nombre")
        while query.next():
            self.combo_equipo_filtro.addItem(query.value(1), query.value(0))
        self.vista.ui.verticalLayout_2.insertWidget(1, self.combo_equipo_filtro)
        self.combo_equipo_filtro.currentTextChanged.connect(self.filtrar_participantes)
        
        # Filtro para calendario: por fase
        self.vista.ui.verticalLayout_3.insertWidget(0, QLabel("Mostrar Fase:"))
        self.combo_fase_cal = QComboBox()
        self.combo_fase_cal.addItem("Todas", "")
        self.combo_fase_cal.addItems(["Octavos", "Cuartos", "Semi", "Final"])
        self.vista.ui.verticalLayout_3.insertWidget(1, self.combo_fase_cal)
        self.combo_fase_cal.currentTextChanged.connect(self.actualizar_calendario_fase)

    def filtrar_equipos(self, texto):
        if texto:
            self.modelo_equipos.setFilter(f"nombre LIKE '%{texto}%'")
        else:
            self.modelo_equipos.setFilter("")
        self.modelo_equipos.select()

    def filtrar_participantes(self):
        if not hasattr(self, 'modelo_participantes'):
            return
        tipo = self.vista.ui.combo_filtro_equipo.currentText()
        equipo = self.combo_equipo_filtro.currentData() if hasattr(self, 'combo_equipo_filtro') else ""
        filtro = ""
        if tipo == "Jugadores":
            filtro = "es_jugador = 1"
        elif tipo == "Árbitros":
            filtro = "es_arbitro = 1"
        if equipo:
            if filtro:
                filtro += f" AND equipo_id = {equipo}"
            else:
                filtro = f"equipo_id = {equipo}"
        self.modelo_participantes.setFilter(filtro)
        self.modelo_participantes.select()

    def actualizar_calendario_fase(self):
        fase = self.combo_fase_cal.currentData()
        self.actualizar_calendario(fase if fase else None)

    def actualizar_calendario(self, fase_filtro=None):
        self.vista.ui.tree_calendario.clear()
        fases = ["Octavos", "Cuartos", "Semi", "Final"]
        if fase_filtro:
            fases = [fase_filtro]
        for fase_nombre in fases:
            parent = QTreeWidgetItem(self.vista.ui.tree_calendario)
            parent.setText(0, fase_nombre)
            
            query = QSqlQuery()
            query.prepare("""
                SELECT p.fecha, p.hora, e1.nombre, e2.nombre, COALESCE(arb.nombre, 'Sin Árbitro'), p.id, COALESCE(p.goles_local, '-'), COALESCE(p.goles_visitante, '-')
                FROM partidos p
                JOIN equipos e1 ON p.equipo_local_id = e1.id
                JOIN equipos e2 ON p.equipo_visitante_id = e2.id
                LEFT JOIN participantes arb ON p.arbitro_id = arb.id
                WHERE p.fase = :fase ORDER BY p.fecha ASC
            """)
            query.bindValue(":fase", fase_nombre)
            query.exec()
            
            while query.next():
                child = QTreeWidgetItem(parent)
                child.setText(0, f"{query.value(0)} {query.value(1)}")
                child.setText(1, f"{query.value(2)} vs {query.value(3)}")
                child.setText(2, f"{query.value(6)} - {query.value(7)}")
                child.setText(3, query.value(4))
                child.setData(0, Qt.UserRole, query.value(5))
        self.vista.ui.tree_calendario.expandAll()
        self.vista.ui.tree_calendario.resizeColumnToContents(0)
        self.vista.ui.tree_calendario.resizeColumnToContents(1)
        self.vista.ui.tree_calendario.resizeColumnToContents(2)
        self.vista.ui.tree_calendario.resizeColumnToContents(3)

    def conectar_botones(self):
        # Equipos
        self.vista.ui.pushButton_2.clicked.connect(self.abrir_formulario_equipo)
        self.vista.ui.btn_edit_equipo.clicked.connect(self.modificar_equipo)
        self.vista.ui.btn_del_equipo.clicked.connect(self.eliminar_equipo)
        
        # Participantes
        self.vista.ui.btn_add_jugador.clicked.connect(self.abrir_formulario_participante)
        self.vista.ui.combo_filtro_equipo.currentTextChanged.connect(self.filtrar_participantes)
        self.vista.ui.btn_delete.clicked.connect(self.eliminar_participante)
        
        # Partidos
        self.vista.ui.pushButton_5.clicked.connect(self.generar_ronda)
        self.vista.ui.btn_clasificacion.clicked.connect(self.mostrar_clasificacion)
        self.vista.ui.btn_nueva_temporada.clicked.connect(self.nueva_temporada)
        if hasattr(self.vista.ui, 'btn_add_partido'):
            self.vista.ui.btn_add_partido.clicked.connect(self.abrir_formulario_partido)
        if hasattr(self.vista.ui, 'btn_del_partido'):
            self.vista.ui.btn_del_partido.clicked.connect(self.eliminar_partido)

    def al_seleccionar_equipo(self, index):
        self.actualizar_logo(index)
        fila = index.row()
        id_equipo = self.modelo_equipos.index(fila, 0).data()
        # self.modelo_participantes.setFilter(f"equipo_id = {id_equipo}")
        # self.modelo_participantes.select()

    def filtrar_por_tipo(self, texto):
        if texto == "Jugadores":
            self.modelo_participantes.setFilter("es_jugador = 1")
        elif texto == "Árbitros":
            self.modelo_participantes.setFilter("es_arbitro = 1")
        else:
            self.modelo_participantes.setFilter("")
        self.modelo_participantes.select()

    def abrir_formulario_participante(self):
        from controllers.participante_dialog_controller import ParticipanteDialog
        es_jugador_defecto = self.vista.ui.combo_filtro_equipo.currentText() != "Árbitros"
        dialogo = ParticipanteDialog(self.modelo_equipos, es_jugador=es_jugador_defecto, parent=self.vista)
        if dialogo.exec():
            datos = dialogo.get_datos()
            record = self.modelo_participantes.record()
            record.setValue("nombre", datos["nombre"])
            record.setValue("fecha_nacimiento", datos["fecha_nacimiento"])
            record.setValue("posicion", datos["posicion"])
            record.setValue("equipo_id", datos["id_equipo"])
            record.setValue("es_jugador", 1 if datos["es_jugador"] else 0)
            record.setValue("es_arbitro", 1 if datos["es_arbitro"] else 0)
            record.setValue("curso", datos["curso"])
            if self.modelo_participantes.insertRecord(-1, record):
                self.modelo_participantes.submitAll()
                self.modelo_participantes.select()

    def eliminar_participante(self):
        indice = self.vista.ui.table_participantes.currentIndex()
        if not indice.isValid():
            QMessageBox.warning(self.vista, "Error", "Selecciona un participante")
            return
        if QMessageBox.question(self.vista, "Eliminar", "¿Borrar este participante?") == QMessageBox.Yes:
            self.modelo_participantes.removeRow(indice.row())
            self.modelo_participantes.select()

    def abrir_formulario_equipo(self):
        dialogo = EquipoDialog(self.vista)
        if dialogo.exec():
            datos = dialogo.get_datos()
            record = self.modelo_equipos.record()
            record.setValue("nombre", datos["nombre"])
            record.setValue("curso", datos["curso"])
            record.setValue("color", datos["color"])
            record.setValue("escudo", datos["escudo"])
            if self.modelo_equipos.insertRecord(-1, record):
                self.modelo_equipos.submitAll()
                self.modelo_equipos.select()

    def abrir_formulario_partido(self):
        dial = QDialog(self.vista)
        dial.setWindowTitle("Programar Partido")
        lay = QVBoxLayout(dial)
        combo_fase = QComboBox()
        combo_fase.addItems(["Octavos", "Cuartos", "Semi", "Final"])
        cb_loc = QComboBox(); cb_loc.setModel(self.modelo_equipos); cb_loc.setModelColumn(1)
        cb_vis = QComboBox(); cb_vis.setModel(self.modelo_equipos); cb_vis.setModelColumn(1)
        txt_fecha = QLineEdit("2026-01-20")
        btn = QPushButton("Guardar Partido")
        lay.addWidget(QLabel("Fase:")); lay.addWidget(combo_fase)
        lay.addWidget(QLabel("Local:")); lay.addWidget(cb_loc)
        lay.addWidget(QLabel("Visitante:")); lay.addWidget(cb_vis)
        lay.addWidget(QLabel("Fecha:")); lay.addWidget(txt_fecha)
        lay.addWidget(btn)
        
        def guardar():
            id_l = self.modelo_equipos.index(cb_loc.currentIndex(), 0).data()
            id_v = self.modelo_equipos.index(cb_vis.currentIndex(), 0).data()
            q = QSqlQuery()
            q.prepare("INSERT INTO partidos (fase, equipo_local_id, equipo_visitante_id, arbitro_id, fecha, hora) VALUES (:f, :l, :v, 1, :fe, '10:00')")
            q.bindValue(":f", combo_fase.currentText()); q.bindValue(":l", id_l); q.bindValue(":v", id_v); q.bindValue(":fe", txt_fecha.text())
            if q.exec():
                dial.accept()
                self.actualizar_calendario()
            else:
                QMessageBox.critical(dial, "Error", q.lastError().text())
        btn.clicked.connect(guardar)
        dial.exec()

    def eliminar_partido(self):
        item = self.vista.ui.tree_calendario.currentItem()
        if not item or item.parent() is None: return
        id_p = item.data(0, Qt.UserRole)
        if QMessageBox.question(self.vista, "Eliminar", "¿Borrar partido?") == QMessageBox.Yes:
            q = QSqlQuery()
            q.prepare("DELETE FROM partidos WHERE id = :id")
            q.bindValue(":id", id_p); q.exec()
            self.actualizar_calendario()

    def actualizar_logo(self, index):
        fila = index.row()
        ruta = self.modelo_equipos.index(fila, 4).data()
        if ruta and os.path.exists(ruta):
            self.vista.ui.logo.setPixmap(QPixmap(ruta).scaled(150, 150, Qt.KeepAspectRatio))
        else:
            self.vista.ui.logo.setText("Sin Escudo")
            
    def modificar_equipo(self):
        indice = self.vista.ui.tabla_equipos.currentIndex()
        if not indice.isValid(): return
        fila = indice.row()
        dialogo = EquipoDialog(self.vista)
        dialogo.ui.txt_nombre.setText(str(self.modelo_equipos.index(fila, 1).data()))
        dialogo.ui.txt_curso.setText(str(self.modelo_equipos.index(fila, 2).data()))
        dialogo.ui.txt_color.setText(str(self.modelo_equipos.index(fila, 3).data()))
        if dialogo.exec():
            datos = dialogo.get_datos()
            self.modelo_equipos.setData(self.modelo_equipos.index(fila, 1), datos["nombre"])
            self.modelo_equipos.setData(self.modelo_equipos.index(fila, 2), datos["curso"])
            self.modelo_equipos.setData(self.modelo_equipos.index(fila, 3), datos["color"])
            self.modelo_equipos.setData(self.modelo_equipos.index(fila, 4), datos["escudo"])
            self.modelo_equipos.submitAll()
            self.modelo_equipos.select()

    def eliminar_equipo(self):
        indice = self.vista.ui.tabla_equipos.currentIndex()
        if not indice.isValid(): return
        id_equipo = self.modelo_equipos.index(indice.row(), 0).data()
        # Check if team has matches
        query = QSqlQuery()
        query.prepare("SELECT COUNT(*) FROM partidos WHERE equipo_local_id = :id OR equipo_visitante_id = :id")
        query.bindValue(":id", id_equipo)
        query.exec()
        query.next()
        if query.value(0) > 0:
            QMessageBox.warning(self.vista, "Error", "No se puede eliminar un equipo que tiene partidos programados.")
            return
        if QMessageBox.question(self.vista, "Eliminar", "¿Seguro que quieres eliminar este equipo?") == QMessageBox.Yes:
            self.modelo_equipos.removeRow(indice.row())
            self.modelo_equipos.submitAll()
            self.modelo_equipos.select()

    def setup_creditos(self):
        layout = QVBoxLayout(self.vista.ui.creditos)
        label = QLabel("TorneoFutbol - Gestión de Torneo de Fútbol Escolar\n\nDesarrollado con PySide6\nVersión 1.0\n\nCaracterísticas:\n- Gestión de Equipos con escudos\n- Participantes (Jugadores y Árbitros)\n- Calendario de Partidos por fases\n- Estadísticas de jugadores\n- Interfaz moderna y oscura")
        label.setAlignment(Qt.AlignCenter)
        label.setStyleSheet("color: white; font-size: 14px;")
        layout.addWidget(label)
        self.vista.ui.creditos.setLayout(layout)

    def setup_ayuda(self):
        layout = QVBoxLayout(self.vista.ui.ayuda)
        label = QLabel("Ayuda para TorneoFutbol\n\n- Equipos: Añade equipos con nombre, curso, color y escudo.\n- Participantes: Registra jugadores y árbitros, asigna a equipos.\n- Calendario: Programa partidos, edita resultados con doble click en un partido, genera rondas automáticamente.\n- Créditos: Información del programa.\n\nPara más ayuda, consulta el manual de usuario.")
        label.setAlignment(Qt.AlignTop)
        label.setWordWrap(True)
        label.setStyleSheet("color: white; font-size: 12px;")
        layout.addWidget(label)
        self.vista.ui.ayuda.setLayout(layout)

    def setup_iconos(self):
        style = self.vista.style()
        self.vista.ui.pushButton_2.setIcon(style.standardIcon(QStyle.SP_FileDialogNewFolder))
        self.vista.ui.btn_edit_equipo.setIcon(style.standardIcon(QStyle.SP_FileDialogDetailedView))
        self.vista.ui.btn_del_equipo.setIcon(style.standardIcon(QStyle.SP_TrashIcon))
        self.vista.ui.btn_add_jugador.setIcon(style.standardIcon(QStyle.SP_FileDialogNewFolder))
        self.vista.ui.btn_delete.setIcon(style.standardIcon(QStyle.SP_TrashIcon))
        self.vista.ui.pushButton_5.setIcon(style.standardIcon(QStyle.SP_BrowserReload))
        self.vista.ui.pushButton_2.setToolTip("Añadir un nuevo equipo")
        self.vista.ui.btn_edit_equipo.setToolTip("Modificar el equipo seleccionado")
        self.vista.ui.btn_del_equipo.setToolTip("Eliminar el equipo seleccionado")
        self.vista.ui.btn_add_jugador.setToolTip("Añadir un nuevo participante")
        self.vista.ui.btn_delete.setToolTip("Eliminar el participante seleccionado")
        self.vista.ui.pushButton_5.setToolTip("Generar la siguiente ronda del torneo basada en ganadores")
        self.vista.ui.btn_clasificacion.setToolTip("Mostrar la clasificación actual")
        self.vista.ui.btn_nueva_temporada.setToolTip("Borrar partidos y estadísticas para nueva temporada")

    def generar_ronda(self):
        # Check current phase
        fases = ["Octavos", "Cuartos", "Semi", "Final"]
        query = QSqlQuery("SELECT DISTINCT fase FROM partidos ORDER BY CASE fase WHEN 'Octavos' THEN 1 WHEN 'Cuartos' THEN 2 WHEN 'Semi' THEN 3 WHEN 'Final' THEN 4 END")
        fases_completadas = []
        while query.next():
            fases_completadas.append(query.value(0))
        
        if not fases_completadas:
            # No partidos, generate octavos
            query2 = QSqlQuery("SELECT id, nombre FROM equipos")
            equipos = []
            while query2.next():
                equipos.append((query2.value(0), query2.value(1)))
            if len(equipos) < 16:
                QMessageBox.warning(self.vista, "Error", "Necesitas al menos 16 equipos para generar octavos")
                return
            random.shuffle(equipos)
            equipos = equipos[:16]  # Tomar 16 equipos
            pairs = [(equipos[2*i], equipos[2*i+1]) for i in range(8)]
            for local, visitante in pairs:
                q = QSqlQuery()
                q.prepare("INSERT INTO partidos (fase, equipo_local_id, equipo_visitante_id, fecha, hora) VALUES ('Octavos', :l, :v, '2026-01-20', '10:00')")
                q.bindValue(":l", local[0])
                q.bindValue(":v", visitante[0])
                q.exec()
            QMessageBox.information(self.vista, "Éxito", "Generado bracket de Octavos con 8 partidos")
        else:
            # Find the last completed phase
            last_fase = fases_completadas[-1]
            # Check if all matches in last_fase have winner
            query3 = QSqlQuery()
            query3.prepare("SELECT COUNT(*) FROM partidos WHERE fase = :fase AND ganador_id IS NULL")
            query3.bindValue(":fase", last_fase)
            query3.exec()
            query3.next()
            pendientes = query3.value(0)
            if pendientes > 0:
                QMessageBox.warning(self.vista, "Error", f"Aún hay {pendientes} partidos de {last_fase} sin resultado")
                return
            # Get winners
            query4 = QSqlQuery()
            query4.prepare("SELECT ganador_id FROM partidos WHERE fase = :fase ORDER BY id")
            query4.bindValue(":fase", last_fase)
            query4.exec()
            winners = []
            while query4.next():
                winners.append(query4.value(0))
            winners = list(set(winners))  # Asegurar únicos
            if len(winners) < 2:
                QMessageBox.information(self.vista, "Fin", "Torneo completado")
                return
            # Next fase
            current_index = fases.index(last_fase)
            if current_index + 1 >= len(fases):
                QMessageBox.information(self.vista, "Fin", "Torneo completado")
                return
            next_fase = fases[current_index + 1]
            # Pair winners
            random.shuffle(winners)
            pairs = []
            for i in range(0, len(winners) - (len(winners) % 2), 2):
                pairs.append((winners[i], winners[i+1]))
            for local, visitante in pairs:
                q = QSqlQuery()
                q.prepare("INSERT INTO partidos (fase, equipo_local_id, equipo_visitante_id, fecha, hora) VALUES (:f, :l, :v, '2026-01-21', '10:00')")
                q.bindValue(":f", next_fase)
                q.bindValue(":l", local)
                q.bindValue(":v", visitante)
                q.exec()
            QMessageBox.information(self.vista, "Éxito", f"Generada ronda de {next_fase} con {len(pairs)} partidos")
        
        self.actualizar_calendario()

    def editar_partido(self, item, column):
        if item.parent() is None:
            return
        id_p = item.data(0, Qt.UserRole)
        
        # Get team names and ids
        q_names = QSqlQuery()
        q_names.prepare("SELECT e1.id, e1.nombre, e2.id, e2.nombre FROM partidos p JOIN equipos e1 ON p.equipo_local_id = e1.id JOIN equipos e2 ON p.equipo_visitante_id = e2.id WHERE p.id = :id")
        q_names.bindValue(":id", id_p)
        local_id = local_name = visitante_id = visitante_name = None
        if q_names.exec() and q_names.next():
            local_id = q_names.value(0)
            local_name = q_names.value(1)
            visitante_id = q_names.value(2)
            visitante_name = q_names.value(3)
        
        dialog = QDialog(self.vista)
        dialog.setWindowTitle("Editar Resultado del Partido")
        lay = QVBoxLayout(dialog)
        lbl = QLabel("Introduce los goles:")
        lay.addWidget(lbl)
        le_local = QLineEdit()
        le_visitante = QLineEdit()
        lay.addWidget(QLabel(f"Goles {local_name} (Local):")); lay.addWidget(le_local)
        lay.addWidget(QLabel(f"Goles {visitante_name} (Visitante):")); lay.addWidget(le_visitante)
        
        # Grupo para estadísticas de jugadores
        from PySide6.QtWidgets import QGroupBox, QHBoxLayout
        group = QGroupBox("Asignar Estadísticas a Jugadores")
        group_lay = QVBoxLayout(group)
        
        # Combo equipo
        combo_equipo_est = QComboBox()
        combo_equipo_est.addItem(f"{local_name} (Local)", local_id)
        combo_equipo_est.addItem(f"{visitante_name} (Visitante)", visitante_id)
        group_lay.addWidget(QLabel("Equipo:"))
        group_lay.addWidget(combo_equipo_est)
        
        # Combo jugador
        combo_jugador = QComboBox()
        def update_jugadores():
            equipo_id_sel = combo_equipo_est.currentData()
            combo_jugador.clear()
            query_jug = QSqlQuery()
            query_jug.prepare("SELECT id, nombre FROM participantes WHERE equipo_id = :eid AND es_jugador = 1")
            query_jug.bindValue(":eid", equipo_id_sel)
            query_jug.exec()
            while query_jug.next():
                combo_jugador.addItem(query_jug.value(1), query_jug.value(0))
        combo_equipo_est.currentIndexChanged.connect(update_jugadores)
        update_jugadores()
        group_lay.addWidget(QLabel("Jugador:"))
        group_lay.addWidget(combo_jugador)
        
        # Botones
        btn_gol = QPushButton("+ Gol")
        btn_amarilla = QPushButton("+ Amarilla")
        btn_roja = QPushButton("+ Roja")
        hlay = QHBoxLayout()
        hlay.addWidget(btn_gol)
        hlay.addWidget(btn_amarilla)
        hlay.addWidget(btn_roja)
        group_lay.addLayout(hlay)
        
        def add_gol():
            jug_id = combo_jugador.currentData()
            if jug_id:
                QSqlQuery().exec(f"UPDATE participantes SET goles = goles + 1 WHERE id = {jug_id}")
                self.modelo_participantes.select()
        
        def add_amarilla():
            jug_id = combo_jugador.currentData()
            if jug_id:
                QSqlQuery().exec(f"UPDATE participantes SET t_amarillas = t_amarillas + 1 WHERE id = {jug_id}")
                self.modelo_participantes.select()
        
        def add_roja():
            jug_id = combo_jugador.currentData()
            if jug_id:
                QSqlQuery().exec(f"UPDATE participantes SET t_rojas = t_rojas + 1 WHERE id = {jug_id}")
                self.modelo_participantes.select()
        
        btn_gol.clicked.connect(add_gol)
        btn_amarilla.clicked.connect(add_amarilla)
        btn_roja.clicked.connect(add_roja)
        
        # Botón añadir jugador
        btn_add_jugador = QPushButton("Añadir Jugador al Equipo")
        group_lay.addWidget(btn_add_jugador)
        
        def add_jugador():
            # Cambiar a pestaña participantes
            self.vista.ui.tabWidget.setCurrentIndex(1)
            # Filtrar por el equipo seleccionado
            equipo_id_sel = combo_equipo_est.currentData()
            if hasattr(self, 'combo_equipo_filtro') and equipo_id_sel:
                index = self.combo_equipo_filtro.findData(equipo_id_sel)
                if index >= 0:
                    self.combo_equipo_filtro.setCurrentIndex(index)
            dialog.accept()
        
        btn_add_jugador.clicked.connect(add_jugador)
        
        lay.addWidget(group)
        
        btn = QPushButton("Guardar Resultado")
        lay.addWidget(btn)
        # Cargar datos actuales
        q = QSqlQuery()
        q.prepare("SELECT goles_local, goles_visitante FROM partidos WHERE id = :id")
        q.bindValue(":id", id_p)
        if q.exec() and q.next():
            le_local.setText(str(q.value(0)))
            le_visitante.setText(str(q.value(1)))
        def guardar():
            try:
                gl = int(le_local.text() or 0)
                gv = int(le_visitante.text() or 0)
            except ValueError:
                QMessageBox.warning(dialog, "Error", "Introduce números válidos")
                return
            # Determinar ganador
            if gl > gv:
                wid = local_id
            elif gv > gl:
                wid = visitante_id
            else:
                # Empate: abrir dialog para elegir ganador
                empate_dialog = QDialog(dialog)
                empate_dialog.setWindowTitle("Empate - Elegir Ganador")
                lay_emp = QVBoxLayout(empate_dialog)
                lay_emp.addWidget(QLabel("El partido terminó en empate. Elige el ganador:"))
                combo_ganador = QComboBox()
                combo_ganador.addItem(f"{local_name} (Local)", local_id)
                combo_ganador.addItem(f"{visitante_name} (Visitante)", visitante_id)
                combo_ganador.addItem("Sin ganador (aún)", None)
                lay_emp.addWidget(combo_ganador)
                btn_emp = QPushButton("Aceptar")
                lay_emp.addWidget(btn_emp)
                def aceptar_empate():
                    wid = combo_ganador.currentData()
                    empate_dialog.accept()
                btn_emp.clicked.connect(aceptar_empate)
                if empate_dialog.exec():
                    wid = combo_ganador.currentData()
                else:
                    return  # Cancelado
            q2 = QSqlQuery()
            q2.prepare("UPDATE partidos SET goles_local = :gl, goles_visitante = :gv, ganador_id = :w WHERE id = :id")
            q2.bindValue(":gl", gl)
            q2.bindValue(":gv", gv)
            q2.bindValue(":w", wid)
            q2.bindValue(":id", id_p)
            if q2.exec():
                dialog.accept()
                self.actualizar_calendario()
                self.modelo_participantes.select()
                QMessageBox.information(self.vista, "Éxito", "Resultado actualizado")
            else:
                QMessageBox.critical(dialog, "Error", q2.lastError().text())
        btn.clicked.connect(guardar)
        dialog.exec()

    def asignar_goles(self, equipo_id, num_goles, lado):
        dialog = QDialog(self.vista)
        dialog.setWindowTitle(f"Asignar {num_goles} Goles - Equipo {lado}")
        lay = QVBoxLayout(dialog)
        
        # Obtener jugadores del equipo
        query = QSqlQuery()
        query.prepare("SELECT id, nombre FROM participantes WHERE equipo_id = :eid AND es_jugador = 1")
        query.bindValue(":eid", equipo_id)
        query.exec()
        jugadores = []
        while query.next():
            jugadores.append((query.value(0), query.value(1)))
        
        # Crear spinboxes para cada jugador
        spinboxes = []
        for jid, nombre in jugadores:
            hlay = QHBoxLayout()
            hlay.addWidget(QLabel(f"{nombre}:"))
            spin = QSpinBox()
            spin.setMaximum(num_goles)
            spin.setValue(0)
            spinboxes.append((jid, spin))
            hlay.addWidget(spin)
            lay.addLayout(hlay)
        
        # Etiqueta para mostrar total
        total_label = QLabel(f"Total asignado: 0 / {num_goles}")
        lay.addWidget(total_label)
        
        # Conectar para actualizar total
        def update_total():
            total = sum(spin.value() for _, spin in spinboxes)
            total_label.setText(f"Total asignado: {total} / {num_goles}")
            if total > num_goles:
                total_label.setStyleSheet("color: red;")
            else:
                total_label.setStyleSheet("color: black;")
        
        for _, spin in spinboxes:
            spin.valueChanged.connect(update_total)
        
        # Botón guardar
        btn_guardar = QPushButton("Guardar Asignación")
        lay.addWidget(btn_guardar)
        
        # Botón añadir jugador
        btn_add_jugador = QPushButton("Añadir Jugador al Equipo")
        lay.addWidget(btn_add_jugador)
        
        def guardar_asignacion():
            total = sum(spin.value() for _, spin in spinboxes)
            if total != num_goles:
                QMessageBox.warning(dialog, "Error", f"El total de goles asignados debe ser exactamente {num_goles}. Actualmente: {total}")
                return
            for jid, spin in spinboxes:
                if spin.value() > 0:
                    QSqlQuery().exec(f"UPDATE participantes SET goles = goles + {spin.value()} WHERE id = {jid}")
            dialog.accept()
            self.modelo_participantes.select()  # Actualizar tabla
        
        def add_jugador():
            # Cambiar a pestaña participantes
            self.vista.ui.tabWidget.setCurrentIndex(1)
            # Filtrar por el equipo
            if hasattr(self, 'combo_equipo_filtro'):
                index = self.combo_equipo_filtro.findData(equipo_id)
                if index >= 0:
                    self.combo_equipo_filtro.setCurrentIndex(index)
            dialog.accept()
        
        btn_guardar.clicked.connect(guardar_asignacion)
        btn_add_jugador.clicked.connect(add_jugador)
        
        dialog.exec()

    def mostrar_clasificacion(self):
        dialog = QDialog(self.vista)
        dialog.setWindowTitle("Clasificación del Torneo")
        lay = QVBoxLayout(dialog)
        table = QTableView()
        model = QSqlQueryModel()
        model.setQuery("""
        SELECT e.nombre as Equipo, 
               SUM(CASE WHEN p.ganador_id = e.id THEN 3 WHEN p.goles_local = p.goles_visitante AND (p.equipo_local_id = e.id OR p.equipo_visitante_id = e.id) THEN 1 ELSE 0 END) as Puntos,
               COUNT(p.id) as PJ,
               SUM(CASE WHEN p.ganador_id = e.id THEN 1 ELSE 0 END) as PG,
               SUM(CASE WHEN p.goles_local = p.goles_visitante AND (p.equipo_local_id = e.id OR p.equipo_visitante_id = e.id) THEN 1 ELSE 0 END) as PE,
               SUM(CASE WHEN p.ganador_id != e.id AND p.ganador_id IS NOT NULL AND (p.equipo_local_id = e.id OR p.equipo_visitante_id = e.id) THEN 1 ELSE 0 END) as PP,
               SUM(CASE WHEN p.equipo_local_id = e.id THEN p.goles_local ELSE p.goles_visitante END) as GF,
               SUM(CASE WHEN p.equipo_local_id = e.id THEN p.goles_visitante ELSE p.goles_local END) as GC,
               (SUM(CASE WHEN p.equipo_local_id = e.id THEN p.goles_local ELSE p.goles_visitante END) - SUM(CASE WHEN p.equipo_local_id = e.id THEN p.goles_visitante ELSE p.goles_local END)) as DG
        FROM equipos e
        LEFT JOIN partidos p ON (p.equipo_local_id = e.id OR p.equipo_visitante_id = e.id) AND p.ganador_id IS NOT NULL
        GROUP BY e.id, e.nombre
        ORDER BY Puntos DESC, DG DESC
        """)
        table.setModel(model)
        table.resizeColumnsToContents()
        lay.addWidget(table)
        btn_export = QPushButton("Exportar a CSV")
        lay.addWidget(btn_export)
        def exportar():
            import csv
            with open("clasificacion.csv", "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["Equipo", "Puntos", "PJ", "PG", "PE", "PP", "GF", "GC", "DG"])
                for row in range(model.rowCount()):
                    data = []
                    for col in range(model.columnCount()):
                        data.append(str(model.data(model.index(row, col))))
                    writer.writerow(data)
            QMessageBox.information(dialog, "Exportado", "Clasificación exportada a clasificacion.csv")
        btn_export.clicked.connect(exportar)
        btn_top_gol = QPushButton("Top Goleadores")
        lay.addWidget(btn_top_gol)
        def mostrar_top_goleadores():
            dialog_top = QDialog(dialog)
            dialog_top.setWindowTitle("Top Goleadores")
            lay_top = QVBoxLayout(dialog_top)
            table_top = QTableView()
            model_top = QSqlQueryModel()
            model_top.setQuery("SELECT p.nombre, p.curso, e.nombre as Equipo, p.goles FROM participantes p JOIN equipos e ON p.equipo_id = e.id WHERE p.es_jugador = 1 ORDER BY p.goles DESC LIMIT 10")
            table_top.setModel(model_top)
            table_top.resizeColumnsToContents()
            lay_top.addWidget(table_top)
            dialog_top.resize(400, 300)
            dialog_top.exec()
        btn_top_gol.clicked.connect(mostrar_top_goleadores)
        
        btn_top_tar = QPushButton("Top Tarjetas")
        lay.addWidget(btn_top_tar)
        def mostrar_top_tarjetas():
            dialog_tar = QDialog(dialog)
            dialog_tar.setWindowTitle("Top Tarjetas")
            lay_tar = QVBoxLayout(dialog_tar)
            table_tar = QTableView()
            model_tar = QSqlQueryModel()
            model_tar.setQuery("SELECT p.nombre, p.curso, e.nombre as Equipo, p.t_amarillas, p.t_rojas FROM participantes p JOIN equipos e ON p.equipo_id = e.id WHERE p.es_jugador = 1 ORDER BY (p.t_amarillas + p.t_rojas * 2) DESC LIMIT 10")
            table_tar.setModel(model_tar)
            table_tar.resizeColumnsToContents()
            lay_tar.addWidget(table_tar)
            dialog_tar.resize(500, 300)
            dialog_tar.exec()
        btn_top_tar.clicked.connect(mostrar_top_tarjetas)
        
        dialog.resize(600, 400)
        dialog.exec()

    def nueva_temporada(self):
        reply = QMessageBox.question(self.vista, "Nueva Temporada", "¿Borrar todos los partidos y resetear estadísticas de jugadores?")
        if reply == QMessageBox.Yes:
            QSqlQuery().exec("DELETE FROM partidos")
            QSqlQuery().exec("UPDATE participantes SET goles = 0, t_amarillas = 0, t_rojas = 0")
            self.actualizar_calendario()
            self.modelo_participantes.select()
            QMessageBox.information(self.vista, "Éxito", "Nueva temporada iniciada. Puedes generar la liga de nuevo.")