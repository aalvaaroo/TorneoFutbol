from PySide6.QtWidgets import QDialog, QFileDialog, QMessageBox
from views.dialog_equipo import Ui_Dialog

class EquipoDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        self.setWindowTitle("Formulario de Equipo")
        
        # Variable para guardar la ruta de la imagen
        self.ruta_imagen = ""
        
        # Conectar el botón de cargar imagen
        self.ui.cargarImagen.clicked.connect(self.seleccionar_imagen)

    def seleccionar_imagen(self):
        # Abrimos el explorador de archivos
        archivo, _ = QFileDialog.getOpenFileName(
            self, 
            "Seleccionar Escudo", 
            "", 
            "Imágenes (*.png *.jpg *.jpeg)"
        )
        if archivo:
            self.ruta_imagen = archivo
            # Cambiamos el texto del botón para saber que se cargó
            self.ui.cargarImagen.setText("¡Imagen Cargada!")

    def accept(self):
        if not self.ui.txt_nombre.text().strip():
            QMessageBox.warning(self, "Error", "El nombre del equipo es obligatorio.")
            return
        if not self.ui.txt_curso.text().strip():
            QMessageBox.warning(self, "Error", "El curso es obligatorio.")
            return
        super().accept()

    def get_datos(self):
        """Devuelve todos los campos para la base de datos"""
        return {
            "nombre": self.ui.txt_nombre.text(),
            "curso": self.ui.txt_curso.text(),
            "color": self.ui.txt_color.text(),
            "escudo": self.ruta_imagen  # Aquí va la ruta del archivo
        }