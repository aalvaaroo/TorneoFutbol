from PySide6.QtWidgets import QStyledItemDelegate
from PySide6.QtGui import QPixmap, QIcon
from PySide6.QtCore import Qt, QSize

class ImageDelegate(QStyledItemDelegate):
    def paint(self, painter, option, index):
        # Obtenemos la ruta de la imagen desde el modelo
        ruta = index.data(Qt.DisplayRole)
        
        if ruta:
            pixmap = QPixmap(ruta)
            if not pixmap.isNull():
                # Calculamos el tamaño para que quepa en la celda
                icon = QIcon(pixmap)
                # Dibujamos el icono centrado
                icon.paint(painter, option.rect, Qt.AlignCenter)
        else:
            super().paint(painter, option, index)

    def sizeHint(self, option, index):
        return QSize(50, 50) # Tamaño de la celda del escudo