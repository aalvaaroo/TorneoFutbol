import os
import sys
from PySide6.QtSql import QSqlDatabase, QSqlQuery

def obtener_ruta_recurso(ruta_relativa):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, ruta_relativa)

def conectar():
    db = QSqlDatabase.addDatabase("QSQLITE")
    ruta_db = obtener_ruta_recurso("models/torneoFutbol_sqlite.db")
    db.setDatabaseName(ruta_db)

    if not db.open():
        return False

    query = QSqlQuery()
    query.exec("PRAGMA foreign_keys = ON;")

    query.exec("""
        CREATE TABLE IF NOT EXISTS equipos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            curso TEXT NOT NULL,
            color TEXT,
            escudo TEXT
        )
    """)

    query.exec("""
        CREATE TABLE IF NOT EXISTS participantes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            fecha_nacimiento TEXT,
            curso TEXT,
            es_jugador INTEGER DEFAULT 1,
            es_arbitro INTEGER DEFAULT 0,
            posicion TEXT, 
            equipo_id INTEGER,
            goles INTEGER DEFAULT 0,
            t_amarillas INTEGER DEFAULT 0,
            t_rojas INTEGER DEFAULT 0,
            FOREIGN KEY(equipo_id) REFERENCES equipos(id) ON DELETE SET NULL
        )
    """)
    
    query.exec("""
        CREATE TABLE IF NOT EXISTS partidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fase TEXT, 
            equipo_local_id INTEGER,
            equipo_visitante_id INTEGER,
            arbitro_id INTEGER,
            goles_local INTEGER DEFAULT 0,
            goles_visitante INTEGER DEFAULT 0,
            fecha TEXT,
            hora TEXT,
            ganador_id INTEGER,
            id_partido_siguiente INTEGER, 
            FOREIGN KEY(equipo_local_id) REFERENCES equipos(id),
            FOREIGN KEY(equipo_visitante_id) REFERENCES equipos(id),
            FOREIGN KEY(ganador_id) REFERENCES equipos(id),
            FOREIGN KEY(arbitro_id) REFERENCES participantes(id),
            FOREIGN KEY(id_partido_siguiente) REFERENCES partidos(id)
        )
               
    """
    )
        # Insertar árbitro de ejemplo
    query = QSqlQuery()
    query.exec("""
        INSERT OR IGNORE INTO participantes (id, nombre, es_arbitro)
        VALUES (1, 'Árbitro Principal', 1)
    """)
    
    # Insertar equipos de ejemplo
    query.exec("""
        INSERT OR IGNORE INTO equipos (id, nombre, curso, color)
        VALUES (17, 'Equipo A', '1DAM', 'Rojo'), (18, 'Equipo B', '1DAM', 'Azul')
    """)
    
        # Esto es solo para probar si el árbol funciona
    query = QSqlQuery()
    query.exec("""
        INSERT INTO partidos (fase, equipo_local_id, equipo_visitante_id, arbitro_id, fecha, hora)
        VALUES ('Octavos', 17, 18, NULL, '2026-01-20', '10:00')
    """)
    
    print("Base de datos preparada correctamente.")
    return True