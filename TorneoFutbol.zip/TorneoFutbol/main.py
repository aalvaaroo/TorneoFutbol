import sys
from PySide6.QtWidgets import QApplication, QMainWindow
from models.database import conectar
from views.mainwindow import Ui_MainWindow
from controllers.main_controller import TorneoController

class MyWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle("TorneoFutbol - Gestión de Torneo de Fútbol")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    if not conectar():
        print("Error crítico: No hay base de datos")
        sys.exit()

    ventana = MyWindow()
    controlador = TorneoController(ventana)
    
    try:
        with open("resources/style.qss", "r") as f:
            app.setStyleSheet(f.read())
    except:
        pass
        
    ventana.show()
    sys.exit(app.exec())